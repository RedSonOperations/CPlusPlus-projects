#include <SFML/Graphics.hpp>
#include <ctime>
#include "Board.h"
#include <iostream>

int main()
{
	Board board;
	sf::RenderWindow* window = new sf::RenderWindow(sf::VideoMode(800, 600), "Minesweeper");

	while (window->isOpen())
    {
        sf::Event event;
        while (window->pollEvent(event))
        {
			if (event.type == sf::Event::MouseButtonPressed)
			{
				bool leftClick = (event.mouseButton.button == sf::Mouse::Left);
				board.click(event.mouseButton.x, event.mouseButton.y, leftClick);
			}
            if (event.type == sf::Event::Closed)
                window->close();
        }
       window->clear();
       board.draw(window);
	  window->display();
    }
}