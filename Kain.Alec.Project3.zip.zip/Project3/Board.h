#pragma once
#include <SFML/Graphics.hpp>
#include "Tile.h"
#include <random>


class Board
{
public:
    Board();
	Tile* getTile(int x, int y);

    void click(int x, int y, bool left);
    void clickTile(int x, int y);

    void draw(sf::RenderWindow* window);

private:
    std::map<int, int> generateRandomVector();
    std::map<int, int> loadMinesFromFile(std::string filepath);
    void generateMines(std::map<int, int> mineMap);
    void calculateAdjacent();
    void checkWon();
    Tile* tiles[25][16]; 

	void reset();
	void end();

    int numMines= 0;
    int numClicked=0;
    int numFlagged= 0;

    bool defeat = false;
    bool victory = false;
	bool debugMode = false;

	sf::Texture* faceLose;
	sf::Texture* faceWin;
    sf::Texture* faceHappy;
    sf::Sprite* resetButton;
    sf::Texture* testTexture1;
    sf::Sprite* testSprite1;
    sf::Texture* testTexture2;
    sf::Sprite* testSprite2;
	sf::Sprite* digit1;
	sf::Sprite* digit2;
	sf::Texture* debugTexture;
	sf::Sprite* debugSprite;
    sf::Texture* scoreboard0; //just copy it 9 more x when get the chance (return to later)
    sf::Texture* scoreboard1;
    sf::Texture* scoreboard2;
    sf::Texture* scoreboard3;
    sf::Texture* scoreboard4;
    sf::Texture* scoreboard5;
    sf::Texture* scoreboard6;
    sf::Texture* scoreboard7;
    sf::Texture* scoreboard8;
    sf::Texture* scoreboard9;
	std::vector<sf::Texture*> textures;
    
};