#include <fstream>
#include <iostream>
#include <vector>
#include <string.h>
#include <stdio.h>
#include "Color.h"
using namespace std;

//sets hex values from RGB
void Color::SetValue(int value) {
   R = (unsigned char)((value >> 16) & 255);
	G = (unsigned char)((value >> 8) & 255);
	B = (unsigned char)(value & 255);

	hex = hex + charToHex(R) + charToHex(G) + charToHex(B);
}

void Color::SetName(const char *name) {
	colorName = name;
}

unsigned char Color::GetR() const {
	return R;
}

unsigned char Color::GetG() const {
	return G;
}

unsigned char Color::GetB() const {
	return B;
}

string Color::GetHexValue() const {
	return hex;
}

string Color::GetName() const {
	return colorName;
}

//conversion function - char to hex values
string Color::charToHex(unsigned char input) {
	string output = "";
	//create new stream
	stringstream outHex;
	outHex << std::hex << setfill('0') << setw(2) << (int) input;
	output = outHex.str();
	for (unsigned int i = 0; i < output.length(); i++) {
		output[i] = (char) toupper(output[i]);
	}

	return output;
}