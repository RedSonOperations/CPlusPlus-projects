#include <iostream>
#include <sstream>
#include <iomanip>
#pragma once

using namespace std;

class Color {

private:
	unsigned char R;
	unsigned char B;
	unsigned char G;
	string hex = "0x";
	string colorName;

public:
	//Setter functions
	void SetValue(int value);
	void SetName(const char *name);

	//Getter functions
	unsigned char GetR() const;
	unsigned char GetG() const;
	unsigned char GetB() const;
	string GetHexValue() const;
	string GetName() const;

	//My own conversion function
	string charToHex(unsigned char input);
};



