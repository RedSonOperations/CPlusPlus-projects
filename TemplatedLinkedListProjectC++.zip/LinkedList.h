#pragma once
#include <iostream>
#include <vector>
using namespace std;

template <typename T>
class LinkedList {
public:
	// Default Constructor
	LinkedList()
	{
		nodeCount = 0;
		head = nullptr;
		tail = nullptr;
	}

	// Node Nested Class
	struct Node
	{
	
		Node* next;
		Node* prev;
		T data;

	};

	// Iterator Pointer
	Node * makeIterator()
	{
		iterator = Head();

		return iterator;
	}

	// ========= Insertion ========= //

	void AddNodesHead(const T *data, unsigned int count)
	{
		int invertIndex = (int)count - 1;
		// Call AddHead from bottom of the array in a for loop
		for (int i = invertIndex; i >= 0; i--)
		{
			AddHead(data[i]);
		}
	}

	void AddNodesTail(const T *data, unsigned int count)
	{
		// Call AddTail from top of the array in a for loop
		for (unsigned int i = 0; i < count; i++)
		{
			AddTail(data[i]);
		}

	}

	// ========= Mutators ========== //

	// Insertion Function

	void InsertAt(const T &data, unsigned int index)
	{
		if (index > nodeCount)
		{
			throw "Incorrect Index";
		}
		else if (index == nodeCount)
		{
			// Handles the end of list index
			Node * newNode = new Node();
			newNode->data = data;
			tail->next = newNode;
			newNode->prev = tail;
			newNode->next = nullptr;
			tail = newNode;

			nodeCount++;
		}
		else
		{
			Node * newNode = new Node();
			unsigned int count = 0;
			newNode->data = data;

			iterator = makeIterator();
			// Iterate through nodes in the list till index
			while (count != index)
			{
				iterator = iterator->next;
				count++;
			}
			// Update the new node's attributes
			newNode->prev = iterator->prev;
			newNode->next = iterator;

			//Update the adjacent Nodes
			if (iterator->prev != nullptr)
			{
				iterator->prev->next = newNode;
			}
			else
			{
				head = newNode;
			}

			// Update the old node at i'th position
			iterator->prev = newNode;

			nodeCount++;
		}

	}

	void InsertAfter(Node *node, const T &data)
	{
		// Create a new Node with data
		Node * newNode = new Node();
		newNode->data = data;
		newNode->prev = node;
		newNode->next = node->next;

		// Update the node attributes
		node->next->prev = newNode;
		node->next = newNode;
		nodeCount++;

	}

	void InsertBefore(Node *node, const T &data)
	{
		// Create a new Node with data
		Node * newNode = new Node();
		newNode->data = data;
		newNode->next = node;
		newNode->prev = node->prev;

		// Update the node attributes
		node->prev->next = newNode;
		node->prev = newNode;
		nodeCount++;
	}

	// Removal Functions

	void Clear()
	{
		Node * ptr = Head();
		Node * temp;

		while (ptr != nullptr)
		{
			temp = ptr->next;
			delete ptr;
			ptr = temp;
		}

		head = nullptr;
		tail = nullptr;
		nodeCount = 0;
	}

	bool RemoveHead()
	{
		// Check if List is empty
		if (head == nullptr)
		{
			return false;
		}
		// Check if only one element is remaining
		else if (head->next == nullptr)
		{
			Node * temp = head;
			delete temp;
			head = nullptr;
			tail = nullptr;
			nodeCount--;
			return true;
		}
		else
		{
			Node * temp = head;
			head->next->prev = nullptr;
			head = head->next;
			delete temp;
			nodeCount--;
			return true;
		}

	}

	bool RemoveTail()
	{
		// Check if List is empty
		if (tail == nullptr)
		{
			return false;
		}
		// Check if list has a single element
		else if (tail->prev == nullptr)
		{
			Node * temp = tail;
			delete temp;
			tail = nullptr;
			head = nullptr;
			nodeCount--;
			return true;
		}
		else
		{
			Node * temp = tail;
			tail->prev->next = nullptr;
			tail = tail->prev;
			delete temp;
			nodeCount--;
			return true;
		}

	}

	bool RemoveAt(unsigned int index)
	{
		if (index > nodeCount)
		{
			return false;
		}
		else
		{
			iterator = makeIterator();
			unsigned int indexCounter = 0;

			while (indexCounter != index)
			{
				iterator = iterator->next;
				indexCounter++;
			}

			// If iterator is at Head
			if (iterator->prev == nullptr)
			{
				iterator->next->prev = nullptr;
			}
			// If iterator is at the Tail
			else if (iterator->next == nullptr)
			{
				iterator->prev->next = nullptr;
			}
			// If in the middle of List
			else
			{
				iterator->prev->next = iterator->next;
				iterator->next->prev = iterator->prev;
			}
			delete iterator;
			nodeCount--;

			return true;
		}

	}

	unsigned int Remove(const T &data)
	{
		unsigned int elementsRemoved = 0;
		Node * iterator = head;
		Node* temp;

		while (iterator != nullptr)
		{
			temp = iterator->next;
			if (iterator->data == data)
			{
				// If iterator is at Head
				if (iterator->prev == nullptr)
				{
					iterator->next->prev = nullptr;
				}
				// If iterator is at the Tail
				else if (iterator->next == nullptr)
				{
					iterator->prev->next = nullptr;
				}
				// If in the middle of List
				else
				{
					iterator->prev->next = iterator->next;
					iterator->next->prev = iterator->prev;
				}
				delete iterator;
				elementsRemoved++;
			}
			iterator = temp;
		}
		// Update the nodeCounter
		nodeCount -= elementsRemoved;
		return elementsRemoved;
	}

	// AddHead
	void AddHead(const T &data)
	{
		// Create a temp node
		Node* temp = new Node();
		temp->data = data;
		temp->next = nullptr;
		temp->prev = nullptr;

		if (head == nullptr)
		{
			head = temp;
			tail = temp;
			head->next = nullptr;
			head->prev = nullptr;
		}
		else
		{
			head->prev = temp;
			if (nodeCount == 1)
				tail->prev = temp;
			temp->next = head;
			head = temp;
		}
		nodeCount++;
	}

	// AddTail
	void AddTail(const T &data)
	{
		// Create a temp node
		temp = new Node();
		temp->data = data;
		temp->next = nullptr;
		temp->prev = nullptr;

		if (tail == nullptr)
		{
			head = temp;
			tail = temp;
			tail->next = nullptr;
			tail->prev = nullptr;
		}
		else
		{
			tail->next = temp;
			if (nodeCount == 1)
				head->next = temp;
			temp->prev = tail;
			temp->next = nullptr;
			tail = temp;
			temp = nullptr;
		}
		nodeCount++;
	}


	// ========= Accessors ========== //

	// Finders

	void FindAll(vector<Node *> &outData, const T&value) const
	{
		// Iterate through the List
		Node * iterator = head;

		for (unsigned int i = 0; i < nodeCount; i++)
		{
			// Check if data matches value passed
			if (iterator->data == value)
			{
				//Node * tempPtr = new Node();
				//tempPtr = iterator;
				// Push matched nodes in outData vector
				outData.push_back(iterator);
				//tempPtr = nullptr;
			}
			iterator = iterator->next;

		}

		iterator = nullptr;
	}

	Node *Find(const T &data)
	{
		bool nodeFound = false;
		iterator = makeIterator();

		while (!nodeFound && iterator->next != nullptr)
		{
			if (iterator->data == data)
			{
				nodeFound = true;
			}
			iterator = iterator->next;
		}
		if (nodeFound)
		{
			return iterator->prev;
		}
		else
		{
			return nullptr;
		}

	}

	const Node *Find(const T &data) const
	{
		bool nodeFound = false;
		iterator = makeIterator();

		while (!nodeFound && iterator->next != nullptr)
		{
			if (iterator->data == data)
			{
				nodeFound = true;
			}
			iterator = iterator->next;
		}
		if (nodeFound)
		{
			return iterator->previous;
		}
		else
		{
			return nullptr;
		}
	}

	Node *Tail()
	{
		return tail;
	}

	const Node *Tail() const
	{
		return tail;
	}

	Node *Head()
	{
		return head;
	}

	const Node *Head() const
	{
		return head;
	}

	const Node * GetNode(unsigned int index) const
	{
		if (index > nodeCount)
		{
			throw "Incorrect index";
		}
		else
		{
			unsigned int indexCount = 0;

			Node * iterator = head;

			while (indexCount != index)
			{
				iterator = iterator->next;
				indexCount++;
			}

			return iterator;
		}

	}

	Node * GetNode(unsigned int index)
	{
		if (index > nodeCount)
		{
			throw "Incorrect index";
		}
		else
		{
			unsigned int indexCount = 0;

			Node* iterator = head;

			while (indexCount != index)
			{
				iterator = iterator->next;
				indexCount++;
			}

			return iterator;
		}

	}

	// Print all nodes in forward direction
	void PrintForward() const
	{
		// Create an iterator
		Node * iterator = head;

		while (iterator != nullptr)
		{
			cout << iterator->data << endl;
			iterator = iterator->next;
		}
	}

	// Print all nodes from back to front
	void PrintReverse() const
	{
		// Create an iterator
		Node * iterator = tail;

		while (iterator != nullptr)
		{
			cout << iterator->data << endl;
			iterator = iterator->prev;
		}
	}

	//This function takes in a pointer to a Node—a starting node.
	//From that node, recursively visit each node that follows, in forward order, and print their values.
	//This function MUST be implemented using recursion, or tests using it will be worth no points.
	void PrintForwardRecursive(const Node * node) const
	{
		if (node == nullptr) {
			return;
		}
		cout << node->data << endl;
		PrintForwardRecursive(node->next);
	}

	//Same deal as PrintForwardRecursive, but in reverse.
	void PrintReverseRecursive(const Node * node) const
	{
		if (node == nullptr) {
			return;
		}
		cout << node->data << endl;
		PrintReverseRecursive(node->prev);
	}

	// Get Node Count
	unsigned int NodeCount() const
	{
		return nodeCount;
	}

	/*===== Operators =====*/
	const T &operator[] (unsigned int index) const
	{
		// Return the node at given index
		if (index > nodeCount)
		{
			throw "Incorrect index";
		}
		else
		{
			unsigned int indexCount = 0;

			Node* iterator = head;

			while (indexCount != index)
			{
				iterator = iterator->next;
				indexCount++;
			}

			return iterator->data;
		}
	}

	T &operator[] (unsigned int index)
	{
		// Return the node at given index
		if (index > nodeCount)
		{
			throw "Incorrect index";
		}
		else
		{
			unsigned int indexCount = 0;

			Node* iterator = head;


			while (indexCount != index)
			{
				iterator = iterator->next;
				indexCount++;
			}

			return iterator->data;
		}
	}

	// Equality operator overloading
	bool operator== (const LinkedList<T> &rhs) const
	{
		// Use an iterator to go through the list
		Node * iterator = head;
		bool isEqual = true;

		// Check if number of nodes are equal
		if (nodeCount != rhs.nodeCount)
		{
			return false;
		}

		for (unsigned int i = 0; i < nodeCount; i++)
		{
			if (iterator->data != rhs.GetNode(i)->data)
				isEqual = false;

			iterator = iterator->next;
		}

		return isEqual;
	}

	/*===== The Big Three =====*/

	LinkedList(const LinkedList<T> &list)
	{
		nodeCount = 0;

		for (unsigned int i = 0; i < list.nodeCount; i++)
		{
			AddTail(list.GetNode(i)->data);
		}
	}

	LinkedList<T> &operator= (const LinkedList<T> &rhs)
	{
		nodeCount = 0;

		for (unsigned int i = 0; i < rhs.nodeCount; i++)
		{
			AddTail(rhs.GetNode(i)->data);
		}

		return *this;
	}

	~LinkedList()
	{
		Clear();
	}



private:
	unsigned int nodeCount;
	Node* next;
	Node* prev;
	Node* head;
	Node* tail;
	Node * iterator;
	Node* temp;

};