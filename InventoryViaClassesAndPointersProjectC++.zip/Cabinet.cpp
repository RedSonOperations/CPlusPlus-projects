#include "Cabinet.h"
#include "Shelf.h"
#include "Food.h"
#include <string>
using namespace std;
#include <iostream>
#include <iomanip>

Cabinet::Cabinet() {
	cabinetName = "";
	shelfStorageCapacity = 0;
	shelfCount = 0;
	shelfObjects = nullptr;
}

Cabinet::Cabinet(string cabinetName, int shelfStorageCapacity) {
	this-> cabinetName = cabinetName;
	this-> shelfStorageCapacity = shelfStorageCapacity;
	shelfObjects = new Shelf[shelfStorageCapacity];
}

void Cabinet::AddShelf(const Shelf *s) {
	shelfObjects[shelfCount] = *s;
	shelfCount++;
}

//consists of shelves which consist of food
void Cabinet::ShowInventory() {
	cout << "Inventory of " << cabinetName << endl;
	for (int i = 0; i < shelfStorageCapacity; i++) {
		cout << "Food in " << shelfObjects[i].GetName() << endl;
		shelfObjects[i].ShowInventory();
		cout << endl << endl;
	}
	cout << fixed << setprecision(2);
	cout << "Average price of food: " << "$" << GetAveragePrice() << endl;
}


float Cabinet::GetAveragePrice() {
	int total = 0;
	float sum = 0;
	for (int i = 0; i < shelfStorageCapacity; i++) {
		for (unsigned int j = 0; j < shelfObjects[i].GetCount(); j++) {
			sum += shelfObjects[i].GetFoodList()[j].GetPrice();
			total++;
		}
	}
	sum /= total;
	return sum;
}

//copy constructor
Cabinet::Cabinet(const Cabinet &r) {
	this-> cabinetName = r.cabinetName;
	this-> shelfStorageCapacity = r.shelfStorageCapacity;
	this-> shelfObjects = new Shelf[shelfStorageCapacity];
	for(int i = 0; i<shelfStorageCapacity; i++){
	   this->shelfObjects[i]=r.shelfObjects[i];
	}
	this->cabinetName = r.cabinetName;
}

//assignment operator
Cabinet & Cabinet::operator = (const Cabinet &r) {
   if(shelfObjects != nullptr){
      delete[] shelfObjects;
   }
   
	this-> cabinetName = r.cabinetName;
	this-> shelfStorageCapacity = r.shelfStorageCapacity;
	this->shelfObjects = new Shelf[shelfStorageCapacity];
	for(int i = 0; i<shelfStorageCapacity; i++){
	   this->shelfObjects[i]=r.shelfObjects[i];
	}
	this->cabinetName = r.cabinetName;
	return *this;
}

Cabinet::~Cabinet(){
   delete[] shelfObjects;
}



