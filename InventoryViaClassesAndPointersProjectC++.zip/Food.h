#pragma once
#include <string>
using namespace std;
#include <iostream>
#include <iomanip>

class Food {
private:
	string foodType;
	string food;
	int expYr;
	float price;
	int cals;
public:
	Food();
	Food(string foodType, string food, int expYr, float price, int cals);
	void Display() const; //Print all information on a single line
	string GetYearTypeName() const; //Return a string in the form of "2019 Vegetale Avocado"
	float GetPrice() const; //How much to purchase?
	int GetCals() const;
	~Food();
};
