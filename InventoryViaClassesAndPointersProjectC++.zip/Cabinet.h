#pragma once
//Comments
#include <string>
#include <vector>
using namespace std;
#include <iostream>
#include <iomanip>
#include "Shelf.h"
class Cabinet {
public:
	void ShowInventory();
	float GetAveragePrice();
	Cabinet();
	Cabinet* shelfName=nullptr;
	void AddShelf(const Shelf *f);
	Cabinet(string cabinetName, int shelfStorageCapacity);
	~Cabinet();
	Cabinet(const Cabinet& r); //Copy constructor
	Cabinet &operator = (const Cabinet &r); //assignment operator
private:
	string cabinetName;
	int shelfStorageCapacity=0;
	Shelf* shelfObjects = nullptr;
	int shelfCount=0;
};
