//Comments
#include "Shelf.h"
#include "Food.h"
#include <string>
using namespace std;
#include <iostream>
#include <iomanip>
Shelf::Shelf() {
	MAX_CAP = 0;
	foodCount = 0;
	shelfName = "";
	foodList = nullptr;
}
Shelf::Shelf(string shelfName, int MAX_CAP) {
	this->shelfName = shelfName;
	this->MAX_CAP = MAX_CAP;
	foodList = new Food[MAX_CAP];
}
void Shelf::AddFood(const Food *f) {
	foodList[foodCount] = *f;
	foodCount++;
}
void Shelf::ShowInventory() const {
	for (int i=0; i < foodCount; i++) {
		cout << foodList[i].GetYearTypeName() << "\t$" << foodList[i].GetPrice() << "\t" << foodList[i].GetCals() << " cal" << endl;
	}
}
const Food* Shelf::GetFoodList() const {
	return foodList;
}
unsigned int Shelf::GetCapacity() const {
	return MAX_CAP;
}
unsigned int Shelf::GetCount() const {
	return foodCount;
}
const char* Shelf::GetName() const {
	return shelfName.c_str();
}



//copy constructor
Shelf::Shelf(const Shelf &s) {
	this->MAX_CAP = s.MAX_CAP;
	this->foodCount = s.foodCount;
	this->foodList = new Food[foodCount];
	for(int i = 0; i<foodCount; i++){
	   this->foodList[i]=s.foodList[i];
	}
	this->shelfName = s.shelfName;
}

//assignment operator
Shelf & Shelf::operator = (const Shelf &s) {
   if(foodList != nullptr){
      delete[] foodList;
   }

	this->MAX_CAP = s.MAX_CAP;
   foodList = new Food[MAX_CAP];
	this->foodCount = s.foodCount;
	for(int i=0; i<foodCount; i++){
	   foodList[i]=s.foodList[i];
	}
	this->shelfName = s.shelfName;
   
	return *this;
}

//destructor
Shelf::~Shelf(){
	delete[] foodList;
}


