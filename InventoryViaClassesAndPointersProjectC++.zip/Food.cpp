//Comments
#include "Food.h"
#include <string>
using namespace std;
#include <iostream>
#include <iomanip>

Food::Food(){
	foodType = "";
	food = "";
	expYr = 0;
	price = 0;
	cals = 0;
}
Food::Food(string foodType, string food, int expYr, float price, int cals) {
	this->foodType = foodType;
	this->food = food;
	this->expYr = expYr;
	this->price = price;
	this->cals = cals;
}

void Food::Display() const {
	//cout << foodList[i].GetYearTypeName() << "\t$" << foodList[i].GetPrice() << "\t" << foodList[i].GetCals() << " cals" << endl;
}

string Food::GetYearTypeName() const {
	string expYear = to_string(expYr);
	return expYear + "\t" + foodType + " " + food;
}

float Food::GetPrice() const {
	return price;
}

int Food::GetCals() const {
	return cals;
}

Food::~Food(){
}