#pragma once
//Comments
#include <string>
using namespace std;
#include <iostream>
#include <iomanip>
#include "Food.h"
class Shelf {
public:
	Shelf();
	Shelf(string shelfName, int MAX_CAP);
	Food* foodList = nullptr;
	void AddFood(const Food *f);
	void ShowInventory() const;
	const Food* GetFoodList() const;
	unsigned int GetCapacity() const;
	unsigned int GetCount() const;
	const char* GetName() const;
	Shelf(const Shelf& s); //Copy constructor
	Shelf &operator = (const Shelf &s); //assignment operator
	~Shelf(); //Destructor
private:
	string shelfName;
	int MAX_CAP;
	int foodCount=0;
};
