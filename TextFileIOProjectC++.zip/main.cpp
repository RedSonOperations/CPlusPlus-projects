#include <iostream>
using namespace std;
#include <fstream>
#include <string>
#include <iomanip>
#include <sstream>
#include <vector>

//class(es)
struct LegoSet {
	LegoSet();
	string name;
	string setNum;
	string theme;
	float price;
	int minifigs;
	int pieceCount;
};

LegoSet::LegoSet()
{
	name = "";
	setNum = "";
	theme = "";
	price = 0.0f;
	minifigs = 0;
	pieceCount = 0;
}

//Function prototypes
void printSet(vector<LegoSet> Lego, int index);

int main()
{
	cout << std::fixed << setprecision(2);
	cout << "Which file(s) to open?\n";
	cout << "1. lego1.csv" << endl;
	cout << "2. lego2.csv" << endl;
	cout << "3. lego3.csv" << endl;
	cout << "4. All 3 files" << endl;
	int option;
	int count = 0;
	string line = "";
	LegoSet Lego;


	cin >> option;

	ifstream file;

	vector<LegoSet> vectLego;

	/*======= Load data from file(s) =======*/
	if (option == 1) {
		file.open("lego1.csv");
		if (file.fail()) {
			cerr << "Error opening file" << endl;
			exit(1);
		}
		getline(file, line);
		while (getline(file, line)) {
			count++;
			LegoSet Lego;
			stringstream ss(line);
			string newString;
			getline(ss, newString, ',');
			Lego.setNum = newString;
			getline(ss, newString, ',');
			Lego.theme = newString;
			getline(ss, newString, ',');
			Lego.name = newString;
			getline(ss, newString, ',');
			try {
				int stringtoInt1 = stoi(newString);
				Lego.minifigs = stringtoInt1;
			}
			catch (invalid_argument) {
				Lego.minifigs = -1;
			}
			getline(ss, newString, ',');
			try {
				int stringToInt2 = stoi(newString);
				Lego.pieceCount = stringToInt2;
			}
			catch (invalid_argument) {
				Lego.pieceCount = -1;
			}
         getline(ss, newString, ',');
			try {
				float stringToFloat = stof(newString);
				Lego.price = stringToFloat;
			}
			catch (invalid_argument) {
				Lego.price = -1;
			}
			vectLego.push_back(Lego);
		}
		//for(unsigned int i = 0; i<vectLego.size(); i++){
		   //cout << vectLego[i].name << endl;
		//}
	}
	else if (option == 2) {
		file.open("lego2.csv");
		if (file.fail()) {
			cerr << "Error opening file" << endl;
			exit(1);
		}
		getline(file, line);
		while (getline(file, line)) {
			count++;
			LegoSet Lego;
			stringstream ss(line);
			string newString;
			getline(ss, newString, ',');
			Lego.setNum = newString;
			getline(ss, newString, ',');
			Lego.theme = newString;
			getline(ss, newString, ',');
			Lego.name = newString;
			getline(ss, newString, ',');
			try {
				int stringtoInt1 = stoi(newString);
				Lego.minifigs = stringtoInt1;
			}
			catch (invalid_argument) {
				Lego.minifigs = -1;
			}
			getline(ss, newString, ',');
			try {
				int stringToInt2 = stoi(newString);
				Lego.pieceCount = stringToInt2;
			}
			catch (invalid_argument) {
				Lego.pieceCount = -1;
			}
         	getline(ss, newString, ',');
			try {
				float stringToFloat = stof(newString);
				Lego.price = stringToFloat;
			}
			catch (invalid_argument) {
				Lego.price = -1;
			}
			vectLego.push_back(Lego);
		}
			//for(unsigned int i = 0; i<vectLego.size(); i++){
		   //cout << vectLego[i].price << endl;
		//}
	}
	else if (option == 3) {
		file.open("lego3.csv");
		if (file.fail()) {
			cerr << "Error opening file" << endl;
			exit(1);
		}
		getline(file, line);
		while (getline(file, line)) {
			count++;
			LegoSet Lego;
			stringstream ss(line);
			string newString;
			getline(ss, newString, ',');
			Lego.setNum = newString;
			getline(ss, newString, ',');
			Lego.theme = newString;
			getline(ss, newString, ',');
			Lego.name = newString;
		
			getline(ss, newString, ',');
			try {
				int stringtoInt1 = stoi(newString);
				Lego.minifigs = stringtoInt1;
			}
			catch (invalid_argument) {
				Lego.minifigs = -1;
			}
			getline(ss, newString, ',');
			try {
				int stringToInt2 = stoi(newString);
				Lego.pieceCount = stringToInt2;
			}
			catch (invalid_argument) {
				Lego.pieceCount = -1;
			}
         	getline(ss, newString, ',');
			try {
				float stringToFloat = stof(newString);
				Lego.price = stringToFloat;
			}
			catch (invalid_argument) {
				Lego.price = -1;
			}
			vectLego.push_back(Lego);
		}
	}
	else if (option == 4) {
		file.open("lego1.csv");
		if (file.fail()) {
			cerr << "Error opening file" << endl;
			exit(1);
		}
		getline(file, line);
		while (getline(file, line)) {
			count++;
			LegoSet Lego;
			stringstream ss(line);
			string newString;
			getline(ss, newString, ',');
			Lego.setNum = newString;
			getline(ss, newString, ',');
			Lego.theme = newString;
			getline(ss, newString, ',');
			Lego.name = newString;
			getline(ss, newString, ',');
			try {
				int stringtoInt1 = stoi(newString);
				Lego.minifigs = stringtoInt1;
			}
			catch (invalid_argument) {
				Lego.minifigs = -1;
			}
			getline(ss, newString, ',');
			try {
				int stringToInt2 = stoi(newString);
				Lego.pieceCount = stringToInt2;
			}
			catch (invalid_argument) {
				Lego.pieceCount = -1;
			}
			getline(ss, newString, ',');
			try {
				float stringToFloat = stof(newString);
				Lego.price = stringToFloat;
			}
			catch (invalid_argument) {
				Lego.price = -1;
			}
			vectLego.push_back(Lego);
		}
		file.close();
		
		file.open("lego2.csv");
		if (file.fail()) {
			cerr << "Error opening file" << endl;
			exit(1);
		}
		getline(file, line);
		while (getline(file, line)) {
			count++;
			LegoSet Lego;
			stringstream ss(line);
			string newString;
			getline(ss, newString, ',');
			Lego.setNum = newString;
			getline(ss, newString, ',');
			Lego.theme = newString;
			getline(ss, newString, ',');
			Lego.name = newString;
			getline(ss, newString, ',');
			try {
				int stringtoInt1 = stoi(newString);
				Lego.minifigs = stringtoInt1;
			}
			catch (invalid_argument) {
				Lego.minifigs = -1;
			}
			getline(ss, newString, ',');
			try {
				int stringToInt2 = stoi(newString);
				Lego.pieceCount = stringToInt2;
			}
			catch (invalid_argument) {
				Lego.pieceCount = -1;
			}
				getline(ss, newString, ',');
			try {
				float stringToFloat = stof(newString);
				Lego.price = stringToFloat;
			}
			catch (invalid_argument) {
				Lego.price = -1;
			}
			vectLego.push_back(Lego);
		}
		file.close();
		
		file.open("lego3.csv");
		if (file.fail()) {
			cerr << "Error opening file" << endl;
			exit(1);
		}
		getline(file, line);
		while (getline(file, line)) {
			count++;
			LegoSet Lego;
			stringstream ss(line);
			string newString;
			getline(ss, newString, ',');
			Lego.setNum = newString;
			getline(ss, newString, ',');
			Lego.theme = newString;
			getline(ss, newString, ',');
			Lego.name = newString;
			getline(ss, newString, ',');
			try {
				int stringtoInt1 = stoi(newString);
				Lego.minifigs = stringtoInt1;
			}
			catch (invalid_argument) {
				Lego.minifigs = -1;
			}
			getline(ss, newString, ',');
			try {
				int stringToInt2 = stoi(newString);
				Lego.pieceCount = stringToInt2;
			}
			catch (invalid_argument) {
				Lego.pieceCount = -1;
			}
			getline(ss, newString, ',');
			try {
				float stringToFloat = stof(newString);
				Lego.price = stringToFloat;
			}
			catch (invalid_argument) {
				Lego.price = -1;
			}
			vectLego.push_back(Lego);
		}
		file.close();
		
		
	}
	/*======= Print out how many sets were loaded =======*/
	cout << "Total number of sets: " << count << endl << endl;


	/*cout << "1. Most Expensive set" << endl;
	cout << "2. Largest piece count" << endl;
	cout << "3. Search for set name containing..." << endl;
	cout << "4. Search themes..." << endl;
	cout << "5. Part count information" << endl;
	cout << "6. Price information" << endl;
	cout << "7. Minifigure information" << endl;
	cout << "8. If you bought one of everything..." << endl;
	cout << "0. Exit" << endl;
	*/


	int choice;
	cin >> choice;
	cin.get();  // Clear newline character for any later input

	/*======= Based on the choice, execute the appropriate task and show the results =======*/
	if (choice == 1) {
		int count1 = 0;
		float tempPrice = vectLego[0].price;
		for (unsigned int i = 0; i < vectLego.size(); i++) {
			if (vectLego[i].price > tempPrice) {
				tempPrice = vectLego[i].price;
				count1 = i;
			}
		}
		//cout << vectLego[i].price << endl;
		cout << "The most expensive set is: " << endl;
		printSet(vectLego, count1);
	}

	if (choice == 2) {
		int count2 = 0;
		int tempPcCount = vectLego[0].pieceCount;
		for (unsigned int i = 0; i < vectLego.size(); i++) {
			if (vectLego[i].pieceCount > tempPcCount) {
				tempPcCount = vectLego[i].pieceCount;
				count2 = i;
			}
		}
		cout << "The set with the highest parts count: " << endl;
		printSet(vectLego, count2);
	}
	if (choice == 3) {
		vector<LegoSet> TempLego;
		string keyword1 = "";
		string keyword2 = "";
		cin >> keyword1;
		cin >> keyword2;
		getline(cin, keyword1);
		getline(cin, keyword2);
		for (unsigned int i = 0; i < vectLego.size(); i++) {
			if (vectLego[i].name.find(keyword1) != string::npos && vectLego[i].name.find(keyword2) != string::npos){ //|| index != 0) {
				TempLego.push_back(vectLego[i]);
			}
		}
	if(TempLego.size() == 0) {
		cout << "No sets found matching that search term" << endl;
	}
	else {
		cout << "Sets matching \"" << keyword1 << keyword2 << "\":" << endl;
	}
		for (unsigned int i = 0; i < TempLego.size(); i++) {
			cout << TempLego[i].setNum << " " << TempLego[i].name << " $" << TempLego[i].price << endl;
		}
	}
	if (choice == 4) {
		vector<LegoSet> TempLego1;
		string keyword2 = "";
		string keyword3 = "";
		cin >> keyword2;
		cin >> keyword3;
		getline(cin, keyword2);
		getline(cin, keyword3);
		for (unsigned int i = 0; i < vectLego.size(); i++) {
			if (vectLego[i].theme.find(keyword2) != string::npos && vectLego[i].theme.find(keyword3) != string::npos){ //|| index != 0) {
				TempLego1.push_back(vectLego[i]);
			}
		}
	   if(TempLego1.size() == 0) {
		   cout << "No sets containing '" << keyword2 << "'" << endl;
	   }
	   else {
		   cout << "Sets matching \"" << keyword2 << " " << keyword3 << "\":" << endl;
			   
	   }
		for (unsigned int i = 0; i < TempLego1.size(); i++) {
	   	cout << TempLego1[i].setNum << " " << TempLego1[i].name << " $" << TempLego1[i].price << endl;
		}
		cout << endl << endl;
		}
		if (choice == 5) {
			int sum = 0;
			int average = 0;
			for (unsigned int i = 0; i < vectLego.size(); i++) {
				sum += vectLego[i].pieceCount;
			}
			average = sum / count;
			cout << "Average part count for " << count << "sets: " << average << endl;
		}
		if (choice == 6) {
			float sum2 = 0;
			float average2 = 0;
			float tempPrice1 = vectLego[0].price;
			float tempPrice2 = vectLego[0].price;
			int count3 = 0;
			int count4 = 0;
			for (unsigned int i = 0; i < vectLego.size(); i++) {
				sum2 += vectLego[i].price;
				if (vectLego[i].price > tempPrice1) {
					tempPrice1 = vectLego[i].price;
					count3 = i;
				}
				else if (vectLego[i].price < tempPrice2) {
					tempPrice2 = vectLego[i].price;
					count4 = i;
				}
			}
			average2 = sum2 / count;
			cout << "Average price for " << count << "sets: $" << average2 << endl << endl;
			cout << "Least expensive set: " << endl;
			printSet(vectLego, count4);
			cout << endl;
			cout << "Most expensive set: " << endl;
			printSet(vectLego, count3);
			cout << endl;
		}
		if (choice == 7) {
			int sum3 = 0;
			int average3 = 0;
			int tempMinis = vectLego[0].minifigs;
			int count5 = 0;
			for (unsigned int i = 0; i < vectLego.size(); i++) {
				sum3 += vectLego[i].minifigs;
				if (vectLego[i].minifigs > tempMinis) {
					tempMinis = vectLego[i].minifigs;
					count5 = i;
				}
			}
			average3 = sum3 / count;
			cout << "Average number of minifigures: " << average3 << endl;
			cout << "Set with the most minifigures: " << endl;
			printSet(vectLego, count5);
			cout << endl;
		}
		if (choice == 8) {
			float sum4 = 0.0f;
			int sum5 = 0;
			int sum6 = 0;
			for (unsigned int i = 0; i < vectLego.size(); i++) {
				sum4 += vectLego[i].price;
				sum5 += vectLego[i].pieceCount;
				sum6 += vectLego[i].minifigs;
			}
			cout << "If you bought one of everything... " << endl << endl;
			cout << "It would cost: $" << sum4 << endl;
			cout << "You would have " << sum5 << " pieces in your collection" << endl;
			cout << "You would have an army of " << sum6 << " minifigures!" << endl << endl;
		}
		if (choice == 0) {
			file.close();
			exit(0);
		}


		return 0;
	
}

	void printSet(vector<LegoSet> Lego, int index)
	{
		cout << "Name: " << Lego[index].name << endl;
		cout << "Number: " << Lego[index].setNum << endl;
		cout << "Theme: " << Lego[index].theme << endl;
		cout << "Price: $" << Lego[index].price << endl;
		cout << "Minifigures: " << Lego[index].minifigs << endl;
		cout << "Piece count: " << Lego[index].pieceCount << endl;
	}