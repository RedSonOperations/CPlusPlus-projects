#pragma once
#include <string>
using namespace std;
#include <iostream>
#include <iomanip>
#include <stdexcept>

template <typename T>
class ABQ {
public:
	T* queue;

	ABQ(); //Default constructor. Maximum capacity should be set to 1, and current size set to 0 
	ABQ(unsigned int capacity); //Constructor for an ABQ with the specified starting maximum capacity.

	void enqueue(T data); //Add a new item to end of the queue and resizes if necessary.
	void Resize(unsigned int newSize); //Resizes queue when necessary
	T dequeue(); //Remove the item at front of the queue, resizes if necessary, and return the value removed.Throws - 1 if the queue is empty.
	T peek(); //Return the value of the item at the front of the queue, without removing it.Throws - 1 if the queue is empty. 
	unsigned int getSize(); //Returns the current number of items in the ABQ. 
	unsigned int getMaxCapacity(); //Returns the current max capacity of the ABQ.
	T* getData(); //Returns the array representing the queue.

	ABQ(const ABQ &d); //Copy Constructor 
	ABQ &operator=(const ABQ &d); //Assignment operator.  
	~ABQ(); //Destructor

private:
	unsigned int size;
	unsigned int capacity;
	float scale_factor;
};

template<typename T>
ABQ<T>::ABQ()
{
	size = 0;
	capacity = 1;
	scale_factor = 2.0f;
	queue = new T[capacity];
}

template<typename T>
ABQ<T>::ABQ(unsigned int capacity)
{
	size = 0;
	scale_factor = 2.0f;
	this->capacity = capacity;
	queue = new T[capacity];
}

template<typename T>
void ABQ<T>::enqueue(T data)
{
	if (size == capacity) {
		Resize((unsigned int)(capacity * scale_factor));
	}
	queue[size] = data;
	size++;
}

template<typename T>
void ABQ<T>::Resize(unsigned int newSize)
{
	if (newSize < 0) {
		throw runtime_error("Item not peeked at properly!");
	}
	T* resize_arr = new T[newSize];

	if (newSize > capacity) {
		capacity = newSize;
		//resize_arr = new T[capacity];
		for (unsigned int i = 0; i < size;i++) {
			resize_arr[i] = queue[i];
		}
	}

	else if (newSize < capacity) {

		if (((float)size / capacity) < (1 / scale_factor)) {
			capacity = capacity * (1 / scale_factor);
			delete[] resize_arr;
			resize_arr = new T[capacity];
			for (unsigned int i = 0; i < newSize; i++) {
				resize_arr[i] = queue[i];
			}
         delete[] queue;
         queue = resize_arr;
         return;

		}

      delete[] resize_arr;
		return;
	}
	else {
		resize_arr = new T[capacity];
		for (unsigned int i = 0; i < newSize; i++) { //if size doesn't work change "size" to 'newSize'.
			resize_arr[i] = queue[i];
		}
	}

   if(queue){
      delete[] queue;
   }
	queue = resize_arr;
}

template<typename T>
T ABQ<T>::dequeue()
{
	if (size == 0) {
		throw - 1;
	}
	size--;
	T temp = queue[0];
	for (unsigned int i = 0; i < capacity-1; i++) {
		   queue[i] = queue[i + 1]; 
	}	
	Resize(size);

	
	return temp;
	

}

template<typename T>
T ABQ<T>::peek()
{
	if (size > 0) {
		return queue[0];
	}
	else {
		throw - 1;
	}
}

template<typename T>
unsigned int ABQ<T>::getSize()
{
	return size;
}

template<typename T>
unsigned int ABQ<T>::getMaxCapacity()
{
	return capacity;
}

template<typename T>
T * ABQ<T>::getData()
{
	return queue;
}

//copy constructor
template<typename T>
ABQ<T>::ABQ(const ABQ &d)
{
	this->capacity = d.capacity;
	this->size = d.size;
	this->queue = new T[capacity];
	for (unsigned int i = 0; i < capacity; i++) {
		this->queue[i] = d.queue[i];
	}
}

//assignment operator
template<typename T>
ABQ<T> & ABQ<T>::operator=(const ABQ &d)
{
	if (queue != nullptr) {
		delete[] queue;
	}
	this->capacity = d.capacity;
	this->size = d.size;
	this->queue = new T[capacity];
	for (unsigned int i = 0; i < capacity; i++) {
		this->queue[i] = d.queue[i];
	}
	return *this;
	// TODO: insert return statement here
}

//destructor
template<typename T>
ABQ<T>::~ABQ()
{
	delete[] queue;
}
