#pragma once
#include <string>
using namespace std;
#include <iostream>
#include <iomanip>
#include <stdexcept>

template <typename T>
class ABS {
public:
	T* stack;

	ABS(); //Default constructor. Maximum capacity should be set to 1, and current size set to 0; 
	ABS(unsigned int capacity); //Constructor for an ABS with the specified starting maximum capacity.

	void push(T data); //Add a new item to the top of the stack and resize if necessary.
	void Resize(unsigned int newSize); //Resizes stack when necessary
	T pop(); //Remove the item at the top of the stack, resizes if necessary, and return the value removed.Throws - 1 if the stack is empty.
	T peek(); //Return the value of the item at the top of the stack, without removing it.Throws - 1 if the stack is empty. 
	unsigned int getSize(); //Returns the current number of items in the ABS. 
	unsigned int getMaxCapacity(); //Returns the current max capacity of the ABS.
	T* getData(); //Returns the array representing the stack.

	ABS(const ABS &d); //Copy Constructor 
	ABS &operator=(const ABS &d); //Assignment operator.  
	~ABS(); //Destructor
private:
	unsigned int size;
	unsigned int capacity;
	float scale_factor;
};

template<typename T>
ABS<T>::ABS()
{
	size = 0;
	capacity = 1;
	scale_factor = 2.0f;
	stack = new T[capacity];
}

template<typename T>
ABS<T>::ABS(unsigned int capacity)
{
	size = 0;
	scale_factor = 2.0f;
	this->capacity = capacity;
	stack = new T[capacity];
}

template<typename T>
void ABS<T>::push(T data)
{
	if (size == capacity) {
		Resize((unsigned int)(capacity * scale_factor));
	}
	stack[size] = data;
	size++;
}

template<typename T>
void ABS<T>::Resize(unsigned int newSize)
{
	if (newSize < 0) {
		throw runtime_error("Item not peeked at properly!");
	}
	T* resize_arr = new T[newSize];

	if (newSize > capacity) {
	   
		capacity = newSize;
		//resize_arr = new T[capacity];
		for (unsigned int i = 0; i < size;i++) {
			resize_arr[i] = stack[i];
		}
		delete[] stack; 
		stack = resize_arr;
		return;
	}

	else if (newSize < capacity) {

		if (((float)size / capacity) < (1 / scale_factor)) {
			capacity = capacity * (1 / scale_factor);
			delete[] resize_arr;
			resize_arr = new T[capacity];
			for (unsigned int i = 0; i < newSize; i++) {
				resize_arr[i] = stack[i];
			}
			delete[] stack;
			stack = resize_arr;
			return;

		}

		delete[] resize_arr;
		return;
	}
	else {
		resize_arr = new T[capacity];
		for (unsigned int i = 0; i < newSize; i++) { //if size doesn't work change "size" to 'newSize'.
			resize_arr[i] = stack[i];
		}
	}
	if (stack) {
		delete[] stack;
	}

	stack = resize_arr;
}

template<typename T>
T ABS<T>::pop()
{
	if (size == 0) {
		throw - 1;
	}
	size--;
	T temp = stack[size];
	Resize(size);

	
	
	return temp;
	

}

template<typename T>
T ABS<T>::peek()
{
	if (size > 0) {
		return stack[size - 1];
	}
	else {
		throw - 1;
	}
}

template<typename T>
unsigned int ABS<T>::getSize()
{
	return size;
}

template<typename T>
unsigned int ABS<T>::getMaxCapacity()
{
	return this->capacity;
}

template<typename T>
T * ABS<T>::getData()
{
	return stack;
}

//copy constructor
template<typename T>
ABS<T>::ABS(const ABS &d)
{
	this->capacity = d.capacity;
	this->size = d.size;
	this->stack = new T[capacity];
	for (unsigned int i = 0; i < capacity; i++) {
		this->stack[i] = d.stack[i];
	}
}

//assignment operator
template<typename T>
ABS<T> & ABS<T>::operator=(const ABS &d)
{
	if (stack != nullptr) {
		delete[] stack;
	}
	this->capacity = d.capacity;
	this->size = d.size;
	this->stack = new T[capacity];
	for (unsigned int i = 0; i < capacity; i++) {
		this->stack[i] = d.stack[i];
	}
	return *this;
	// TODO: insert return statement here
}

//destructor
template<typename T>
ABS<T>::~ABS()
{
	delete[] stack;
}
