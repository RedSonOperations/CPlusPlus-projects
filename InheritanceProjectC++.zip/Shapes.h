#pragma once
#include <iostream>
#include <string>
#include <cmath>
#define PI 3.14159f
using namespace std;

class Shape
{
public:
	virtual void Scale(float scaleFactor) = 0;
	virtual void Display() const = 0;
	virtual ~Shape(){};
};

class Shape2D : virtual public Shape
{
public:
	virtual float Area() const = 0;
	void ShowArea() const;
	virtual string GetName2D() const = 0;
	bool operator>(const Shape2D &other);
	bool operator<(const Shape2D &other);
	bool operator==(const Shape2D &other);
};

class Shape3D : virtual public Shape
{
public:
	virtual float Volume() const = 0;
	void ShowVolume() const;
	virtual string GetName3D() const = 0;
	bool operator>(const Shape3D &other);
	bool operator<(const Shape3D &other);
	bool operator==(const Shape3D &other);
};

//2D shapes
class Square : virtual public Shape2D
{
public:
	Square(float sideLength)
	{
		this->sideLength = sideLength;
		this->area = sideLength * sideLength;
		this->name = "Square";
	}
	Square() {
		this->area = 0;
		this->sideLength = 0;
		this->name = "Square";
	}
	float Area() const {
		return area;
	}
	string GetName2D() const {
		return this->name;
	}
	void Scale(float scaleFactor) {
		this->sideLength *= scaleFactor;
		this->area = sideLength * sideLength;
	}
	void Display() const {
		cout << "The area of the " << GetName2D() << " is : " << Area() << endl;
		cout << "Length of a side: " << sideLength << endl;
	}

private:
	float area;
	float sideLength;
	string name;
};

class Rectangle : virtual public Shape2D
{
public:
	Rectangle() {
		this->area = 0;
		this->width = 0;
		this->width = 0;
		this->name = "Rectangle";
	}
	Rectangle(float width, float height) {
		this->width = width;
		this->height = height;
		this->area = width * height;
		this->name = "Rectangle";
	}
	float Area() const {
		return area;
	}
	string GetName2D() const {
		return this->name;
	}
	void Scale(float scaleFactor) {
		this->width *= scaleFactor;
		this->height *= scaleFactor;
		this->area = width * height;
	}
   void Display() const {
		cout << "The area of the " << GetName2D() << " is : " << Area() << endl;
		cout << "Length: " << width << endl;
		cout << "Width: " << height << endl;
	}

private:
	float area;
	float width;
	float height;
	string name;
};

class Triangle : virtual public Shape2D
{
public:
	Triangle() {
		this->area = 0;
		this->width = 0;
		this->width = 0;
		this->name = "Triangle";
	}
	Triangle(float width, float height) {
		this->width = width;
		this->height = height;
		this->area = .5f * width * height;
		this->name = "Triangle";
	}
	float Area() const {
		return area;
	}
	string GetName2D() const {
		return this->name;
	}
	void Scale(float scaleFactor) {
		this->width *= scaleFactor;
		this->height *= scaleFactor;
		this->area = 0.5f * (width * height);
	}
	void Display() const {
		cout << "The area of the " << GetName2D() << " is : " << Area() << endl;
		cout << "Base: " << width << endl;
		cout << "Height: " << height << endl;
	}

private:
	float area;
	float width;
	float height;
	string name;
};

class Circle : virtual public Shape2D
{
public:
	Circle() {
		this->area = 0;
		this->radius = 0;
		this->name = "Circle";
	}
	Circle(float radius) {
		this->radius = radius;
		this->area = PI * pow(radius, 2);
		this->name = "Circle";
	}
	float Area() const {
		return area;
	}
	string GetName2D() const {
		return this->name;
	}
	void Scale(float scaleFactor) {

		this->radius *= scaleFactor;
		this->area = PI*radius*radius;

	}
	void Display() const {
		cout << "The area of the " << GetName2D() << " is : " << Area() << endl;
		cout << "Radius: " << radius << endl;
	}

private:
	float area;
	float radius;
	string name;
};

class Ellipse : virtual public Shape2D
{
public:
	Ellipse() {
		this->area = 0;
		this->lengthOfMajorAxis = 0;
		this->lengthOfMinorAxis = 0;
		this->name = "Ellipse";
	}
	Ellipse(float lengthMajorAxis, float lengthMinorAxis) {
		this->lengthOfMajorAxis = lengthMajorAxis;
		this->lengthOfMinorAxis = lengthMinorAxis;
		this->area = PI * lengthMajorAxis * lengthMinorAxis;
		this->name = "Ellipse";
	}
	float Area() const {
		return area;
	}
	string GetName2D() const {
		return this->name;
	}
	void Scale(float scaleFactor) {
		this->lengthOfMajorAxis *= scaleFactor;
		this->lengthOfMinorAxis *= scaleFactor;
		this->area=PI*lengthOfMajorAxis*lengthOfMinorAxis;
	}
	void Display() const {
		cout << "The area of the " << GetName2D() << " is : " << Area() << endl;
		cout << "Length of semi-major axis: " << lengthOfMajorAxis << endl;
		cout << "Length of semi-minor axis: " << lengthOfMinorAxis << endl;	
	}

private:
	float area;
	float lengthOfMajorAxis;
	float lengthOfMinorAxis;
	string name;
};

class Trapezoid : virtual public Shape2D
{
public:
	Trapezoid() {
		this->parallelSideLength = 0;
		this->parallelSide2Length = 0;
		this->height = 0;
		this->area = 0;
		this->name= "Trapezoid";
	}
	Trapezoid(float parallelSideLength, float parallelSide2Length, float height) {
		this->parallelSideLength = parallelSideLength;
		this->parallelSide2Length = parallelSide2Length;
		this->height = height;
		this->area = .5f * (parallelSideLength + parallelSide2Length) * height;
		this->name = "Trapezoid";
	}
	float Area() const {
		return area;
	}
	string GetName2D() const {
		return this->name;
	}
	void Scale(float scaleFactor) {
		this->parallelSideLength *= scaleFactor;
		this->parallelSide2Length *= scaleFactor;
		this->height *= scaleFactor;
		this->area = 0.5f * (parallelSideLength + parallelSide2Length) * height;
	}
	void Display() const {
		cout << "The area of the " << GetName2D() << " is : " << Area() << endl;
		cout << "Length of side A: " << parallelSideLength << endl;
		cout << "Length of side B: " << parallelSide2Length << endl;
      cout << "Height: " << height << endl;
	}

private:
	float area;
	float parallelSideLength;
	float parallelSide2Length;
	float height;
	string name;
};

class Sector : virtual public Shape2D
{
public:
	//convert to radians
	Sector() {
		this->radius = 0;
		this->degreeAngle = 0;
		this-> name = "Sector";
	}
	Sector(float radius, float degreeAngle) {
		this->radius = radius;
		this->degreeAngle = degreeAngle;
		this->radAngle = degreeAngle * PI / 180.0f;
		this->area = 0.5f * pow(radius, 2) * radAngle;
		this->name = "Sector";
	}
	float Area() const {
		return area;
	}
	string GetName2D() const {
		return this->name;
	}
	void Scale(float scaleFactor) {
		this->radius *= scaleFactor;
		this->radAngle *=scaleFactor;
		this->degreeAngle *= scaleFactor;
		this->area =0.5f * pow(radius, 2) * radAngle;

	}
	void Display() const {
		cout << "The area of the " << GetName2D() << " is : " << Area() << endl;
		cout << "Radius: " << radius << endl;
		cout << "Angle in radians: " << radAngle << endl;
		cout << "Angle in degrees: " << degreeAngle << endl;

	}

private:
	float radius;
	float degreeAngle; 
	float radAngle;
	float area;
	string name;
};

//3D shapes
class TriangularPyramid : virtual public Shape3D, private Triangle
{
public:
	TriangularPyramid() {
		this->volume = 0;
		this->area = 0;
		this->BaseHeight = 0;
		this->PyramidHeight = 0;
		this->lengthTriangleBase = 0;
		this-> name = "TriangularPyramid";
	}
	TriangularPyramid(float PyramidHeight, float lengthTriangleBase, float BaseHeight) {
		Triangle triangle;
		this->name = "TriangularPyramid";
		this->PyramidHeight = PyramidHeight;
		this->lengthTriangleBase = lengthTriangleBase;
		this->BaseHeight = BaseHeight;
		this->area = (0.5f*lengthTriangleBase * BaseHeight);
		this->volume = (1.0f / 3.0f) * (area) * PyramidHeight;

	}
	float Volume() const {
		return volume;
	}
	string GetName3D() const {
		return this->name;
	}
	void Scale(float scaleFactor) {
		Triangle triangle;
		this->PyramidHeight *= scaleFactor;
		this->lengthTriangleBase *= scaleFactor;
		this->BaseHeight *= scaleFactor;
		this->area=0.5f*lengthTriangleBase*BaseHeight;
		//this->area *= scaleFactor;
		this->volume = (1.0f/3.0f) * area * PyramidHeight;
	}
	void Display() const {
		cout << "The volume of the " << GetName3D() << " is : " << Volume() << endl;
		cout << "The height is: " << PyramidHeight << endl;
		cout << "The area of the Triangle is : " << area << endl;
		cout << "Base: " << lengthTriangleBase << endl;
		cout << "Height: " << BaseHeight << endl;
	}

private:
	float PyramidHeight;
	float lengthTriangleBase;
	float BaseHeight;
	float volume;
	float area;
	string name;
};

class RectangularPyramid : virtual public Shape3D, private Rectangle
{
public:
	RectangularPyramid() {
		this->volume = 0;
		this->WidthBase = 0;
		this->PyramidHeight = 0;
		this->lengthRectangleBase = 0;
		this-> name = "RectangularPyramid";
	}
	RectangularPyramid(float PyramidHeight, float lengthRectangleBase, float WidthBase) {
		Rectangle rectangle;
		this->name = "RectangularPyramid";
		this->PyramidHeight = PyramidHeight;
		this->lengthRectangleBase = lengthRectangleBase;
		this->WidthBase = WidthBase;
		this->area = lengthRectangleBase*WidthBase;
		this->volume = (1.0f / 3.0f) * area * PyramidHeight;

	}
	float Volume() const {
		return volume;
	}
	string GetName3D() const {
		return this->name;
	}
	void Scale(float scaleFactor) {
		Triangle triangle;
		this->PyramidHeight *= scaleFactor;
		this->lengthRectangleBase *= scaleFactor;
		this->WidthBase *= scaleFactor;
		this->area =lengthRectangleBase*WidthBase;
		this->volume = (1.0f / 3.0f) * area * PyramidHeight;
		
	}
	void Display() const {
		cout << "The volume of the " << GetName3D() << " is : " << Volume() << endl;
		cout << "The height is: " << PyramidHeight << endl;
		cout << "The area of the Rectangle is : " << area << endl;
		cout << "Length: " << lengthRectangleBase << endl;
		cout << "Width: " << WidthBase << endl;
	}

private:
	float PyramidHeight;
	float lengthRectangleBase;
	float WidthBase;
	float volume;
	float area;
	string name;
};

class Cylinder : virtual public Shape3D, private Circle
{
public:
	Cylinder() {
		this->volume = 0;
		this->radius = 0;
		this->CylinderHeight = 0;
		this->area = 0;
		this->name = "Cylinder";
	}
	Cylinder(float CylinderHeight, float radius) {
		Circle circle;
		this->name = "Cylinder";
		this->radius = radius;
		this->CylinderHeight = CylinderHeight;
		this->area = PI * (radius*radius);
		this->volume = area * CylinderHeight;

	}
	float Volume() const {
		return volume;
	}
	string GetName3D() const {
		return this->name;
	}
	void Scale(float scaleFactor) {
		Circle circle;
		this->radius *= scaleFactor;
		this->CylinderHeight *= scaleFactor;
		this->area = PI * (radius*radius);		
		this->volume = area * CylinderHeight;
	}
	void Display() const {
		cout << "The volume of the " << GetName3D() << " is : " << Volume() << endl;
		cout << "The height is: " << CylinderHeight << endl;
		cout << "The area of the Circle is : " << area << endl;
		cout << "Radius: " << radius << endl;
	}

private:
	float CylinderHeight;
	float radius;
	float volume;
	float area;
	string name;
};

class Sphere : virtual public Shape3D, private Circle
{
public:
	Sphere() {
		this->volume = 0;
		this->radius = 0;
		this->area = 0;
		this-> name = "Sphere";
	}
	Sphere(float radius) {
		Circle circle;
		this->name = "Sphere";
		this->radius = radius;
		this->area = PI * radius * radius;
		this->volume = (4.0f / 3.0f) * (area *radius);

	}

	float Volume() const {
		return volume;
	}
	string GetName3D() const {
		return this->name;
	}
	void Scale(float scaleFactor) {
		Circle circle;
		this->radius *= scaleFactor;
		this->area = PI * radius * radius;
		this->volume = (4.0f / 3.0f) * (area *radius);
	
	}
	void Display() const {
		cout << "The volume of the " << GetName3D() << " is : " << Volume() << endl;
		cout << "The area of the Circle is : " << area << endl;
		cout << "Radius: " << radius << endl;

	}

private:
	float radius;
	float volume;
	float area;
	string name;
};





