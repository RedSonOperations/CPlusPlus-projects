#include "Shapes.h"


void Shape2D::ShowArea() const {
	cout << "The area of the " << GetName2D() << "is : ";
	cout << Area() << endl;
}

bool Shape2D::operator>(const Shape2D &other) {
	return this->Area() > other.Area() ? true : false;
}

bool Shape2D::operator<(const Shape2D &other) {
	return  this->Area() < other.Area() ? true : false;
}

bool Shape2D::operator==(const Shape2D &other) {
	return this->Area() == other.Area() ? true : false;
}

void Shape3D::ShowVolume() const {
	cout << "The volume of the " << GetName3D() << "is : ";
	cout << Volume() << endl;
}

bool Shape3D::operator>(const Shape3D &other) {
	return this->Volume() > other.Volume() ? true : false;
}

bool Shape3D::operator<(const Shape3D &other) {
	return this->Volume() < other.Volume() ? true : false;
}

bool Shape3D::operator==(const Shape3D &other) {
	return this->Volume() == other.Volume() ? true : false;
}
