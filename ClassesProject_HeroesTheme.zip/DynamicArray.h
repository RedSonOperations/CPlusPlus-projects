#pragma once
#include <string>
using namespace std;
#include <iostream>
#include <iomanip>
#include <stdexcept>

template<typename T>
class DynamicArray {
public:
	T* array1;
	//accessors first
	unsigned int GetCapacity() const;
	unsigned int GetSize() const;
	const T*  GetData() const;

	//return specific element from internal array
	const T &operator[](unsigned int index) const;
	T &operator[](unsigned int index);

	const T&At(unsigned int index) const;
	T&At(unsigned int index);

	//mutators
	void Add(const T &data);
	void Resize(unsigned int newSize);
	void Remove(unsigned int index);

	//default constructor
	DynamicArray();
	//constructor with initial capacity
	DynamicArray(unsigned int capacity);

	//trilogy of evil
	DynamicArray(const DynamicArray &d);
	DynamicArray &operator = (const DynamicArray &d);
	~DynamicArray();

private:
	unsigned int capacity;
	unsigned int size;

};


template<typename T>
DynamicArray<T>::DynamicArray()
{
	capacity = 0;
	size = 0;
	array1 = nullptr;

}

template<typename T>
DynamicArray<T>::DynamicArray(unsigned int capacity)
{
	this->capacity = capacity;
	size = 0;
	array1 = new T[capacity];
}


template<typename T>
unsigned int DynamicArray<T>::GetCapacity() const
{
	return capacity;
}

template<typename T>
unsigned int DynamicArray<T>::GetSize() const
{
	return size;
}

template<typename T>
const T * DynamicArray<T>::GetData() const
{
	return array1;
}

template<typename T>
const T & DynamicArray<T>::operator[](unsigned int index) const
{
	// TODO: insert return statement here
	if (index < size) {
		return array1[index];
	}
	else {
		throw runtime_error("Error! Invalid index");
	}
}

template<typename T>
T & DynamicArray<T>::operator[](unsigned int index)
{
	// TODO: insert return statement here
	if (index < size) {
		return array1[index];
	}
	else {
		throw runtime_error("Error! Invalid index");
	}
}

template<typename T>
const T & DynamicArray<T>::At(unsigned int index) const
{
	// TODO: insert return statement here
	if (index < size) {
		return array1[index];
	}
	else {
		throw runtime_error("Error! Invalid index");
	}
}

template<typename T>
T & DynamicArray<T>::At(unsigned int index)
{
	// TODO: insert return statement here
	if (index < size) {
		return array1[index];
	}
	else {
		throw runtime_error("Error! Invalid index");
	}
}

template<typename T>
void DynamicArray<T>::Add(const T &data)
{
	if(size == capacity){
	   Resize(size+1);
	}
	array1[size] = data;
	size++;
}

template<typename T>
void DynamicArray<T>::Resize(unsigned int newSize)
{
   if(newSize < 0){
	   throw runtime_error("Error! Invalid index");
	}
	T* resize_arr = new T[newSize];
	if(newSize < size){
	   for (unsigned int i = 0; i < newSize; i++) {
		   resize_arr[i] = array1[i];
	   }
	   size = newSize;
	}
	else{
	   for(unsigned int i = 0; i < size; i++){
         resize_arr[i] = array1[i];
	   }
	}

	delete[] array1;
	array1 = resize_arr;
	cout << "Resizing... old capacity: " << capacity << " New capacity: " << newSize << endl;
	capacity = newSize;
}

template<typename T>
void DynamicArray<T>::Remove(unsigned int index)
{
	if (index <= 0 || index > size) {
		throw runtime_error("Error! Invalid index");
	}
	
	for (unsigned int i = index; i < size; i++) {
		   array1[i] = array1[i + 1]; 
	}	
   size--;
}

//copy constructor
template<typename T>
DynamicArray<T>::DynamicArray(const DynamicArray &d)
{
	this-> capacity = d.capacity;
	this->size = d.size;
	this->array1 = new T[capacity];
	for (unsigned int i = 0; i < capacity; i++) {
		this->array1[i] = d.array1[i];
	}

}

//assignment operator
template<typename T>
DynamicArray<T> & DynamicArray<T>::operator=(const DynamicArray<T> &d)
{
	if (array1 != nullptr) {
		delete[] array1;
	}
	this->capacity = d.capacity;
	this->size = d.size;
	this->array1 = new T[capacity];
	for (unsigned int i = 0; i < capacity; i++) {
		this->array1[i] = d.array1[i];
	}
	return *this;
	// TODO: insert return statement here
}

template<typename T>
DynamicArray<T>::~DynamicArray()
{
	delete[] array1;
}


